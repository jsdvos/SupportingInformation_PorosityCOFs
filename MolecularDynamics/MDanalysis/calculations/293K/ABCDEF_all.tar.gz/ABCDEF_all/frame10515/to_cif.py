import numpy as np
from yaff import System
from molmod.units import angstrom, deg
from molmod.periodic import periodic as pt

sys = System.from_file('frame10515.chk')
lengths, angles = sys.cell.parameters
a, b, c = lengths/angstrom
alpha, beta, gamma = angles/deg
frac = np.dot(sys.pos, np.linalg.inv(sys.cell.rvecs))

fn= 'frame10515.cif'
f = open(fn, 'w')
print("data_frame9982\n", file=f)
print("_cell_length_a\t\t%.6f" %a, file=f)
print("_cell_length_b\t\t%.6f" %b, file=f)
print("_cell_length_c\t\t%.6f" %c, file=f)
print("_cell_angle_alpha\t%.6f" %alpha, file=f)
print("_cell_angle_beta\t%.6f" %beta, file=f)
print("_cell_angle_gamma\t%.6f" %gamma, file=f)
print("_symmetry_space_group_name_H-M\t'P 1'\n_symmetry_Int_Tables_number\t\t1\n", file=f)
print("loop_\n\t_symmetry_equiv_pos_as_xyz\n\tx,y,z\n", file=f)
print("loop_\n\t_atom_site_label\n\t_atom_site_type_symbol\n\t_atom_site_fract_x\n\t_atom_site_fract_y\n\t_atom_site_fract_z", file=f)
for i in range(len(sys.numbers)):
    s = pt[sys.numbers[i]].symbol
    print("\t%s\t%s\t%.6f\t%.6f\t%.6f" %(s+str(i), s, frac[i,0], frac[i,1], frac[i,2]), file=f)
f.close()
