#! /usr/bin/python

import sys, os, posixpath
import numpy as np

import pyobjcryst
from pyobjcryst.powderpattern import *
from pyobjcryst.crystal import *
from pyobjcryst.radiation import RadiationType

deg = np.pi/180.

# Code to redirect stdout
from contextlib import contextmanager

def fileno(file_or_fd):
    fd = getattr(file_or_fd, 'fileno', lambda: file_or_fd)()
    if not isinstance(fd, int):
        raise ValueError("Expected a file (`.fileno()`) or a file descriptor")
    return fd

@contextmanager
def stdout_redirected(to=os.devnull, stdout=None):
    if stdout is None:
       stdout = sys.stdout

    stdout_fd = fileno(stdout)
    # copy stdout_fd before it is overwritten
    #NOTE: `copied` is inheritable on Windows when duplicating a standard stream
    with os.fdopen(os.dup(stdout_fd), 'wb') as copied:
        stdout.flush()  # flush library buffers that dup2 knows nothing about
        try:
            os.dup2(fileno(to), stdout_fd)  # $ exec >&to
        except ValueError:  # filename
            with open(to, 'wb') as to_file:
                os.dup2(to_file.fileno(), stdout_fd)  # $ exec > to
        try:
            yield stdout # allow code to be run with the redirected stdout
        finally:
            # restore stdout to its previous value
            #NOTE: dup2 makes stdout_fd inheritable unconditionally
            stdout.flush()
            os.dup2(copied.fileno(), stdout_fd)  # $ exec >&copied

def calculate_frame(input_name,output_name,refpattern,skiprows,full_pattern,wavelength,rad_type,max2theta,numpoints,peakwidth,save_fhkl,detail_fhkl):
    c = CreateCrystalFromCIF(input_name)

    px = PowderPattern()
    px.SetWavelength(wavelength)
    px.SetRadiationType(rad_type)

    if refpattern is None:
        px.SetPowderPatternX(np.linspace(0, max2theta*deg, numpoints))
    else:
        px.ImportPowderPattern2ThetaObs(refpattern,skiprows) # skip no lines
        if full_pattern:
            # use an identical range as the reference pattern, but with minimum of 0
            ttheta = px.GetPowderPatternX()
            step = np.round((ttheta[1]-ttheta[0])/deg,5)
            full_ttheta = np.arange(0, max(ttheta/deg)+step, step)*deg
            px.SetPowderPatternX(full_ttheta)

    diffData = px.AddPowderPatternDiffraction(c)
    diffData.SetReflectionProfilePar(ReflectionProfileType.PROFILE_PSEUDO_VOIGT,(peakwidth*deg)**2)

    #Export data - calculated reflections
    calc = px.GetPowderPatternComponent(0)

    stdout_fd = sys.stdout.fileno()
    if save_fhkl:
     with open(output_name + '_fhkl.dat', 'w') as f, stdout_redirected(f):
         calc.PrintFhklCalc()

    if save_fhkl and detail_fhkl:
     with open(output_name + '_fhkl_detail.dat', 'w') as f, stdout_redirected(f):
         calc.PrintFhklCalcDetail()

    # Export data - 2theta space
    ttheta = px.GetPowderPatternX()
    icalc = px.GetPowderPatternCalc()

    with open(output_name + '.dat','w') as f:
        f.write('# 2theta \t ICalc \n')
        for i in range(len(ttheta)):
            f.write("{:7.5f}\t{:10.8f}\n".format(ttheta[i]/deg,icalc[i]))

    # Calculate - q space
    wavelength = calc.GetWavelength()
    qspace = 4.*np.pi/wavelength*np.sin(ttheta/2.)
    with open(output_name + '_q.dat','w') as f:
        f.write('# Q \t ICalc \n')
        for i in range(len(ttheta)):
            f.write("{:7.5f}\t{:10.8f}\n".format(qspace[i],icalc[i]))

if __name__ == '__main__':
    # Calculate the frame
    fname_in = sys.argv[1]
    fname_out = 'output'
    calculate_frame(input_name=fname_in, output_name=fname_out, refpattern=None,skiprows=0,
                    full_pattern=None,wavelength=1.54056,rad_type=RadiationType.RAD_XRAY,
                    max2theta=50,numpoints=1001,peakwidth=0.14,save_fhkl=True,detail_fhkl=False
                )

