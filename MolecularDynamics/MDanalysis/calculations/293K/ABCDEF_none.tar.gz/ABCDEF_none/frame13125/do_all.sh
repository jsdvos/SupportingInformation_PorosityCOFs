#!/bin/sh
#
#PBS -N _analyse_ABCDEF_none_293K_frame13125
#PBS -l walltime=00:10:00
#PBS -l nodes=1:ppn=1
#PBS -l mem=7500M
#PBS -m n

cd $PBS_O_WORKDIR

# Create cif
module load yaff/1.6.0-intel-2020a-Python-3.8.2
python to_cif.py

# Derive PXRD
module purge
module load pyobjcryst/2.2.1-foss-2021b
python pxrd_get.py frame13125.cif
rm output_fhkl.dat # Heavy unnecessary file

# Analysis pore
network -res frame13125.res -sa 1.82 1.82 3000 frame13125.sa -vol 1.82 1.82 3000 frame13125.vol frame13125.cif
cat frame13125.res frame13125.sa frame13125.vol > frame13125.geo

