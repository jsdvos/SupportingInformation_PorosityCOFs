#!/bin/sh
#
#PBS -N _analyse_ABCDEF_full38_293K_frame11340
#PBS -l walltime=00:10:00
#PBS -l nodes=1:ppn=1
#PBS -l mem=7500M
#PBS -m n

cd $PBS_O_WORKDIR

# Create cif
module load yaff/1.6.0-intel-2020a-Python-3.8.2
python to_cif.py

# Derive PXRD
module purge
module load pyobjcryst/2.2.1-foss-2021b
python pxrd_get.py frame11340.cif
rm output_fhkl.dat # Heavy unnecessary file

# Analysis pore
network -res frame11340.res -sa 1.82 1.82 3000 frame11340.sa -vol 1.82 1.82 3000 frame11340.vol frame11340.cif
cat frame11340.res frame11340.sa frame11340.vol > frame11340.geo

