#!/bin/sh
#
#PBS -N _analyse_ABCDEF_full58_77K_frame10035
#PBS -l walltime=00:10:00
#PBS -l nodes=1:ppn=1
#PBS -l mem=7500M
#PBS -m n

cd $PBS_O_WORKDIR

# Create cif
module load yaff/1.6.0-intel-2020a-Python-3.8.2
python to_cif.py

# Derive PXRD
module purge
module load pyobjcryst/2.2.1-foss-2021b
python pxrd_get.py frame10035.cif
rm output_fhkl.dat # Heavy unnecessary file

# Analysis pore
network -res frame10035.res -sa 1.82 1.82 3000 frame10035.sa -vol 1.82 1.82 3000 frame10035.vol frame10035.cif
cat frame10035.res frame10035.sa frame10035.vol > frame10035.geo

