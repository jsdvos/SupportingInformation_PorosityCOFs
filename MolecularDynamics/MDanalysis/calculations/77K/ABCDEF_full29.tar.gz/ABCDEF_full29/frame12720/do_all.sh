#!/bin/sh
#
#PBS -N _analyse_ABCDEF_full29_77K_frame12720
#PBS -l walltime=00:10:00
#PBS -l nodes=1:ppn=1
#PBS -l mem=7500M
#PBS -m n

cd $PBS_O_WORKDIR

# Create cif
module load yaff/1.6.0-intel-2020a-Python-3.8.2
python to_cif.py

# Derive PXRD
module purge
module load pyobjcryst/2.2.1-foss-2021b
python pxrd_get.py frame12720.cif
rm output_fhkl.dat # Heavy unnecessary file

# Analysis pore
network -res frame12720.res -sa 1.82 1.82 3000 frame12720.sa -vol 1.82 1.82 3000 frame12720.vol frame12720.cif
cat frame12720.res frame12720.sa frame12720.vol > frame12720.geo

